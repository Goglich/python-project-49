### Hexlet tests and linter status:
[![Actions Status](https://github.com/Goglich/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Goglich/python-project-49/actions)

brain-even
https://asciinema.org/a/AbAPlUNNNxCYO7r3ip7XnVpdq

brain-calc
https://asciinema.org/a/VQ3iqfmY2FefPz0UnX8a8XrEZ

brain-gcd
https://asciinema.org/a/UbtE24tmioZisq1erDHsScM9y

brain-progression
https://asciinema.org/a/cGHeHQ1t4ndlCpQRR9yTtyFHc